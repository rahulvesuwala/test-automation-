import config from '../../playwright.config';
import { expect, Page } from "@playwright/test";
import { TextView, Button, SelectorType, TextInput } from '@aveone/playwright';
import * as path from 'path';
import Base from "./Base";

const expectedErrorMessage: String = "Error: Oops! It seems like the street address for one or more records couldn't be verified. To ensure accurate processing, please double-check the address information or remove it and re-upload the file. Alternatively, you may click \"Proceed\" to continue with enrichment. Invalid addresses will include null values for enriched columns."

class Dashboard extends Base {


    page: Page
    private addressRowsOnEnrichedTable: any[]; // Declare the variable here

    constructor(page: Page) {
        super(page);
        this.page = page
    }

    /**
     * Navigates to the dashboard page.
     */
    async navigateToHomePage() {
        await super.goTo(config.use?.baseURL);
    }

    async verifyUserAbleToSearch(){

    // Find the search input and type the query
    await new TextInput(this.page, SelectorType.CSS, '[name="q"]').fastType('Playwright');

    // Submit the search form
    await this.page.keyboard.press('Enter');
   
    // Check if results are displayed
    const actualErrorMessage = await new TextView(this.page, SelectorType.CSS, `[class="QpPSMb"]`).getText();
    expect(actualErrorMessage).toEqual('Playwright');
    }

 }

export default Dashboard;  
